#pragma once
#include "payment.h"
class online : public _payment
{
public:
	void onlinepayment(_payment & obj)  
	{

		cout << "payable amount before tax: " << obj.getamt() << endl;
		cout << "tax amount: " << obj.gettax() << endl;
		cout << "your total payable amount is: " << obj.applytax() << endl;

		obj.creditusercard();
		cout << "\n*Amount credited*\n";
	}
};