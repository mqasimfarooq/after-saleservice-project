#pragma once
#include "payment.h"
class onspot : public _payment
{
public:
	void onspotpayment(_payment & obj)
	{
		
		cout << "\nPlease pay upon arrival.";
	}
};