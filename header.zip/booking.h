#pragma once
#include <ctime>
struct tm newtime;

int appendDigit(int base, int append) {
	std::string sBase = std::to_string(base);
	std::string sAppend = std::to_string(append);
	std::string result = sBase + sAppend;
	return std::stoi(result);

}

void fix(char * d, char* m, char* y, char* hr, char* mi) //fixes date and time data to follow correct format
{
	time_t now = time(0);
	localtime_s(&newtime, &now);
	
	std::string s = std::to_string(1 + newtime.tm_hour);
	if (s.size() == 1)//hour
	{
		hr[0] = '0';
		hr[1] = s[0];
	}
	else
	{
		hr[0] = s[0];
		hr[1] = s[1];
	}
	

	s = std::to_string(1 + newtime.tm_min);
	if (s.size() == 1)//min
	{
		mi[0] = '0';
		mi[1] = s[0];
	}
	else
	{
		mi[0] = s[0];
		mi[1] = s[1];
	}

	s = std::to_string(newtime.tm_mday);
	if (s.size() == 1)//day
	{
		d[0] = '0';
		d[1] = s[0];
	}
	else
	{
		d[0] = s[0];
		d[1] = s[1];
	}

	s = std::to_string(1 + newtime.tm_mon);
	if (s.size() == 1)//month
	{
		m[0] = '0';
		m[1] = s[0];
	}
	else
	{
		m[0] = s[0];
		m[1] = s[1];
	}

	s = std::to_string(1900 + newtime.tm_year);//year
	y[0]=s[0];
	y[1]=s[1];
	y[2]=s[2];
	y[3]=s[3];

}



class _booking
{
private:
	char _date[12];
	char _time[6];
	_payment userpayment;
public:

	char* getdate()
	{
		return _date;
	}
	char* gettime()
	{
		return _time;
	}

	_payment getpaymentinfo()
	{
		return userpayment;
	}


	_booking()
	{
		memcpy(_date, "00-00-0000", 12);
		memcpy(_time, "00:00", 6);
	}

	_booking(const char dt[12], const char tm[6],_payment obj)
	{
		memcpy(_date, dt, 12);
		memcpy(_time, tm, 6);
		userpayment = obj;
	}

	bool checkstaffavailability()
	{
		return true;
	}

	void bookappointment(float cost)
	{
		if (checkstaffavailability() == true)
		{

			char d[3], m[3], y[5], hr[3], mi[3];
			long int bookingelapse=-1, actualelapse=0;
			fix(d, m, y, hr, mi);
			_payment obj;
			int tp = 0, x, yy, z;
			int hh, mm;
			while (bookingelapse<actualelapse)
			{
			while (tp < 1 || tp>31)
			{
				cout << "\nEnter Booking Day (between 1 and 31):" << endl;
				cin >> tp;
				if (tp < 1 || tp>31)
				{
					cout << "\nIncorrect data\n";
				}
			}
			x = tp;

			tp = 0;

			while (tp < 1 || tp>12)
			{
				cout << "\nEnter Month (between 1 and 12):" << endl;
				cin >> tp;
				if (tp < 1 || tp>12)
				{
					cout << "\nIncorrect data\n";
				}
			}
			yy = tp;

			tp = 0;

			while (tp < 2021)
			{
				cout << "\nEnter Year (2022 And Above):" << endl;
				cin >> tp;
				if (tp < 2021)
				{
					cout << "\nIncorrect data\n";
				}
			}
			z = tp;
			tp = -1;

			while (tp < 0 || tp>24)
			{
				cout << "\nEnter Appointment Hour (between 00 and 24):" << endl;
				cin >> tp;
				if (tp < 1 || tp>31)
				{
					cout << "\nIncorrect data\n";
				}
			}
			hh = tp;
			tp = -1;

			while (tp < 0 || tp>59)
			{
				cout << "\nEnter Appointment Mins (between 00 and 24):" << endl;
				cin >> tp;
				if (tp < 0 || tp>59)
				{
					cout << "\nIncorrect data\n";
				}
			}
			mm = tp;

			bookingelapse = z;
			appendDigit(bookingelapse,yy);
			appendDigit(bookingelapse, x);
			appendDigit(bookingelapse, hh);
			appendDigit(bookingelapse, mm);
			
			actualelapse = std::stoi(y);
			appendDigit(actualelapse, std::stoi(m));
			appendDigit(actualelapse, std::stoi(d));
			appendDigit(actualelapse, std::stoi(hr));
			appendDigit(actualelapse, std::stoi(mi));

			cout << actualelapse;
			if (bookingelapse < actualelapse)
			{
				cout << "-Booking can be in future only-";
			}
			}
			string ggg= std::to_string(x) + "-" + std::to_string(yy) + "-" + std::to_string(z), hhh= std::to_string(hh) + ":" + std::to_string(mm);
			cout << "\nDay:" << ggg << " time:" << hhh << endl;
			memcpy(_date, ggg.c_str(), 12);
			memcpy(_time,hhh.c_str(),6);
			

			string cno;
			int opt=0;
			while (opt < 1 || opt>2)
			{
				cout << "\nPlease enter an option; 1-On Spot Payment 2-Card Payment: ";
				cin >> opt;
			}
			if (opt == 1)
			{
				float t = 16.00;
				cout << "Booking Complete :)\n";
				_payment temp(t, cost, "     On Spot Payment     ","xxx");

				userpayment = temp;
				onspot obj;
				obj.onspotpayment(userpayment);
			}
			if (opt == 2)
			{
				float t = 16.00;
				string tmp="";
				while (tmp.size() != 16)
				{
					cout << "Enter Card Number: ";
					cin >> tmp;
					if (tmp.size() != 16)
					{
						cout << "\n Card Number Length Should be 16";
					}
				}
				string x = " ";
				while (x.size() != 3)
				{
					cout << "\nEnter CVV: ";
					cin >> x;
					if (x.size() != 3) { cout << "Length of CVV should be 3"; }
				}
				_payment temp(t, cost, tmp.c_str(),x.c_str());
				userpayment = temp;
				online obj;
				obj.onlinepayment(userpayment);
				cout << "\nBooking Complete :)\n";
				
			}


			
		}
	}

};