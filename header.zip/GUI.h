#pragma once



class GUI {

protected:
	string phonenum, password;
	userdashboard ud_obj;
public:
	int enter = 0;
	user returnuser()
	{
		return ud_obj.getuser();
	}
	GUI()
	{
		phonenum = "";
		password = "";
	}
	

	void userdetails()
	{
		ud_obj.showdetails();
	}

	void welcomescreen() {
		cout << "HELLO TO S&J MOTORS" << endl;

	}

	

	bool generateotp() {
		srand(time(0));
		string str = "1234567890";
		int n = str.length();

		// String to hold my OTP
		string OTP;
		int len = 5;
		for (int i = 1; i <= len; i++)
			OTP.push_back(str[rand() % n]);
		ofstream f("otp.txt");
		if (f.is_open()) {
			f << OTP << endl;
		}
		OTP.c_str();

		string t;
		ifstream w("otp.txt");
		if (w.is_open())
			getline(w, t);
		cout << " a otp code will be generated shortly" << endl;
		cout << endl;

		cout << "here is your generated otp code : " << t << endl;


		cout << "now enter the enter code displayed to you for verification" << endl;
		string s;
		cin >> s;
		cout << endl;

		if (s == t) {
			cout << "verification succesfull you have succesfully signed up" << endl;
			return true;
		}

		else {

			return false;
		}


	}


	
};

class lgn :public GUI
{
public:
	bool loginverification(string u, string p)
	{
		ifstream file("logins\\login data.txt");
		if (file.is_open())
		{
			string x, y;
			while (file >> x >> y)
			{
				if (x == u && y == p)
				{
					return 0;
					break;
				}
			}
			cout << "Incorrect Details\n";
			return 1;
		}
		else
		{
			cout << "\nNo User has been signed up yet\n";
			return 1;
		}

	}
	bool login() {
		string u, p;
		cout << "You have reached login page enter PhoneNumber and Password to continue: " << endl;
		cin >> u;
		cin >> p;

		if (loginverification(u, p) == 0)
		{
			generateotp();
			userdashboard tmp(u);
			ud_obj = tmp;
			return true;
		}
		else
		{
			return false;
		}
	}
};

class sgp :public GUI
{
public:
	bool findexistingphone(string p)
	{
		ifstream file("logins\\login data.txt");
		string x, y;
		if (file.is_open() == false) { return 0; }
		while (file >> x >> y)
		{
			if (x == p)
			{
				return 0;
				break;
			}
		}
		return 1;
	}

	void signup()
	{
		string pnum = "xxxxxxxxxxx", name, email;
		char p[12], d[3], m[3], y[5];
		int tp = 0;
		cout << "Enter your phone number to signup to s&j motors app: " << endl;
		cin >> pnum;
		while (findexistingphone(pnum) == 0)
		{
			if (findexistingphone(pnum) == 0)
			{
				cout << "Account already created for this phonenum\n ";
			}
			cout << "\nEnter your phone number to signup to s&j motors app: " << endl;
			cin >> pnum;

		}
		while (pnum.size() != 11)
		{

			if (pnum.size() != 11)
			{
				cout << "Wrong length\n";
			}

			cout << "Enter your phone number to signup to s&j motors app " << endl;
			cin >> pnum;

		}
		phonenum = pnum;
		cout << "\nNow create a password" << endl;
		cin >> password;

		cout << "\nAdditional info.." << endl;
		cout << "\nEnter Name:" << endl;
		getline(cin, name);
		getline(cin, name);
		cout << "\nEnter Email:" << endl;
		cin >> email;
		while (tp < 1 || tp>31)
		{
			cout << "\nEnter Birth Day (between 1 and 31):" << endl;
			cin >> tp;
			if (tp < 1 || tp>31)
			{
				cout << "\nIncorrect data\n";
			}
		}
		std::string s = std::to_string(tp);
		memcpy(d, s.c_str(), 3);
		tp = 0;

		while (tp < 1 || tp>12)
		{
			cout << "\nEnter Birth Month (between 1 and 12):" << endl;
			cin >> tp;
			if (tp < 1 || tp>12)
			{
				cout << "\nIncorrect data\n";
			}
		}
		s = std::to_string(tp);
		memcpy(m, s.c_str(), 3);
		tp = 0;

		while (tp < 1800 || tp>2022)
		{
			cout << "\nEnter Birth Year (between 1800 and 2022):" << endl;
			cin >> tp;
			if (tp < 1800 || tp>2022)
			{
				cout << "\nIncorrect data\n";
			}
		}
		s = std::to_string(tp);
		memcpy(y, s.c_str(), 5);
		user temp(name, pnum.c_str(), email, d, m, y);
		userdashboard tmp(temp);
		ud_obj = tmp;
		ofstream file("logins\\login data.txt", ios::app);
		if (file.is_open() == false)
		{
			ofstream file("logins\\login data.txt");
		}
		if (file.is_open()) {
			file << phonenum << "\t";
			file << password << endl;
		}
		generateotp();
	}
};