#pragma once
#include "GUI.h"
#include <fstream>
using namespace std;
class lgn :public GUI
{
public:
	bool loginverification(string u, string p)
	{
		ifstream file("logins\\login data.txt");
		if (file.is_open())
		{
			string x, y;
			while (file >> x >> y)
			{
				if (x == u && y == p)
				{
					return 0;
					break;
				}
			}
			cout << "Incorrect Details\n";
			return 1;
		}
		else
		{
			cout << "\nNo User has been signed up yet\n";
			return 1;
		}

	}
	bool login() {
		string u, p;
		cout << "You have reached login page enter PhoneNumber and Password to continue: " << endl;
		cin >> u;
		cin >> p;

		if (loginverification(u, p) == 0)
		{
			generateotp();
			userdashboard tmp(u);
			ud_obj = tmp;
			return true;
		}
		else
		{
			return false;
		}
	}
};