#pragma once
class sgp :public GUI
{
public:
	bool findexistingphone(string p)
	{
		ifstream file("logins\\login data.txt");
		string x, y;
		if (file.is_open() == false) { return 0; }
		while (file >> x >> y)
		{
			if (x == p)
			{
				return 0;
				break;
			}
		}
		return 1;
	}

	void signup()
	{
		string pnum = "xxxxxxxxxxx", name, email;
		char p[12], d[3], m[3], y[5];
		int tp = 0;
		cout << "Enter your phone number to signup to s&j motors app: " << endl;
		cin >> pnum;
		while (findexistingphone(pnum) == 0)
		{
			if (findexistingphone(pnum) == 0)
			{
				cout << "Account already created for this phonenum\n ";
			}
			cout << "\nEnter your phone number to signup to s&j motors app: " << endl;
			cin >> pnum;

		}
		while (pnum.size() != 11)
		{

			if (pnum.size() != 11)
			{
				cout << "Wrong length\n";
			}

			cout << "Enter your phone number to signup to s&j motors app " << endl;
			cin >> pnum;

		}
		phonenum = pnum;
		cout << "\nNow create a password" << endl;
		cin >> password;

		cout << "\nAdditional info.." << endl;
		cout << "\nEnter Name:" << endl;
		getline(cin, name);
		getline(cin, name);
		cout << "\nEnter Email:" << endl;
		cin >> email;
		while (tp < 1 || tp>31)
		{
			cout << "\nEnter Birth Day (between 1 and 31):" << endl;
			cin >> tp;
			if (tp < 1 || tp>31)
			{
				cout << "\nIncorrect data\n";
			}
		}
		std::string s = std::to_string(tp);
		memcpy(d, s.c_str(), 3);
		tp = 0;

		while (tp < 1 || tp>12)
		{
			cout << "\nEnter Birth Month (between 1 and 12):" << endl;
			cin >> tp;
			if (tp < 1 || tp>12)
			{
				cout << "\nIncorrect data\n";
			}
		}
		s = std::to_string(tp);
		memcpy(m, s.c_str(), 3);
		tp = 0;

		while (tp < 1800 || tp>2022)
		{
			cout << "\nEnter Birth Year (between 1800 and 2022):" << endl;
			cin >> tp;
			if (tp < 1800 || tp>2022)
			{
				cout << "\nIncorrect data\n";
			}
		}
		s = std::to_string(tp);
		memcpy(y, s.c_str(), 5);
		user temp(name, pnum.c_str(), email, d, m, y);
		userdashboard tmp(temp);
		ud_obj = tmp;
		ofstream file("logins\\login data.txt", ios::app);
		if (file.is_open() == false)
		{
			ofstream file("logins\\login data.txt");
		}
		if (file.is_open()) {
			file << phonenum << "\t";
			file << password << endl;
		}
		generateotp();
	}
};
