

#include <iostream>
#include <fstream>
#include <string>
#include <ctime>
#include <vector>
#include<iostream>
#include<fstream>
#include<cstring>
#include <stdlib.h>
#include<string>
#include <iostream>
#include <fstream>
#include <string>
#include <ctime>
#include <sstream>
#define s6 "\t\t\t\t\t\t"
#define s5 "\t\t\t\t\t"
#define s4 "\t\t\t\t"
#define s3 "\t\t\t"
#define s2 "\t\t"
#define s1 "\t"
#define s0 ""
#define sp0 ""
#define sp1 " "
#define sp2 "  "
#define sp3 "   "
#define sp4 "    "
#define sp5 "     "
#define nl endl
#define cyp "Choose your option : "

using namespace std;
#include "onlinepayment.h"
#include "onspotpayment.h"
#include "payment.h"
#include "booking.h"
#include "user.h"
#include "userdashboard.h"
#include "GUI.h"


class staff {
public:

	string name, ssn, sal, age, exp, casual, sick, study, parental, sdate, edate, days;;
	bool a;
	string job;
	string location;
	staff() {
	}
	staff(string n, int ag, bool b, string loc, string j) {
		name = n;
		age = ag;
		a = b;
		location = loc;
		job = j;

		casual = "20", sick = "15", study = "10", parental = "40"; days = "0";
	}
	void show() {
		if (a) {
			cout << name << "\n Age: " << age << " \n Attendance: Present " << " \n Location: " << location << " \n Job: " << job << endl;
			cout << endl;
		}
		else {
			cout << name << "\n Age: " << age << " \n Attendance: Absent " << " \n Location: " << location << " \n Job: " << job << endl;
			cout << endl;
		}

	}

};

class workshopmanager {

public:

	void addUser()
	{
		staff e;
		cout << nl << s2 << "--- A D D  U S E R ---" << nl << nl;
		cout << s2 << sp2 << "Enter the ID : ";
		cin >> e.ssn;
		e.ssn.resize(8);
		cout << s2 << sp2 << "Enter the Name : ";
		cin >> e.name;
		e.name.resize(8);
		cout << s2 << sp2 << "Enter the Age : ";
		cin >> e.age;
		e.age.resize(8);
		cout << s2 << sp2 << "Enter the Salary : ";
		cin >> e.sal;
		e.sal.resize(8);
		cout << s2 << sp2 << "Enter the Experience : ";
		cin >> e.exp;
		e.exp.resize(8);
		fstream file1, file2, file3;
		file1.open("emp.txt", ios::binary | ios::app);
		file2.open("leave.txt", ios::binary | ios::app);
		file3.open("salary.txt", ios::binary | ios::app);
		if (!file1 || !file2) {
			system("cls");
			cout << s4 << "Error Occured!" << nl;
			return;
		}
		e.casual = e.casual + "/20-0", e.sick = e.sick + "/15-0", e.study = e.study + "/10-0", e.parental = e.parental + "/40-0";
		e.casual.resize(10), e.sick.resize(10), e.study.resize(10), e.parental.resize(10), e.sdate.resize(10), e.edate.resize(10), e.days.resize(5);
		file1 << "\t|" << e.ssn << "|\t" << e.name << "|" << e.age << "|" << e.sal << "|" << e.exp << "|" << nl;
		file2 << e.ssn << "|" << e.name << "|" << e.casual << "|" << e.sick << "|" << e.study << "|" << e.parental << "|" << e.sal << "|" << e.sdate << "|" << e.edate << "|" << e.days << "|" << nl;
		file3 << e.ssn << "|" << e.sal << "|" << nl;
		file1.close();
		file2.close();
		file3.close();

		cout << s4 << "User added successfully!" << nl << nl << nl;
	}

	void modUser()
	{
		char ch;
		string id, str;
		int found = 0, count = 0;
		fstream file1, file2;
		file1.open("emp.txt", ios::binary | ios::in);
		cout << nl << s2 << "--- M O D I F Y  U S E R ---" << nl << nl;
		cout << s2 << sp4 << "Enter Employee ID : ";
		cin >> id;
		id.resize(8);
		if (!file1) {
			system("cls");
			cout << s4 << "Error Occured" << nl;
			return;
		}
		int index = 5;
		while (file1) {
			file1.seekg(index, ios::beg);
			getline(file1, str, '|');

			if (str == id) {
				found = 1;
				break;
			}
			else {
				index += 51;
				str.clear();
				count++;
			}
		}
		file1.close();
		if (found == 1)
		{
		start:
			int ch, beg, end;
			string newstr, str;
			cout << s4 << "1. EDIT AGE" << nl;
			cout << s4 << "2. EDIT SALARY" << nl;
			cout << s4 << "3. EDIT EXPERIENCE" << nl << nl;
			cout << s4 << cyp;
			cin >> ch;
			cout << nl;
			if (ch == 1 || ch == 2 || ch == 3) {
				cout << s4 << "Enter the new value : ";
				cin >> newstr;
			}
			else
				goto start;
			newstr.resize(8);

			file1.open("emp.txt", ios::binary | ios::in);
			file2.open("temp.txt", ios::binary | ios::app);

			while (count--) {
				getline(file1, str);
				file2 << str << endl;
			}
			if (ch == 1)
				beg = 3, end = 2;
			else if (ch == 2)
				beg = 4, end = 1;
			else if (ch == 3)
				beg = 5, end = 0;
			for (int i = 0; i < beg; i++) {
				getline(file1, str, '|');
				file2 << str << "|";
			}

			file2 << newstr << "|";
			getline(file1, str, '|');
			for (int i = 0; i < end; i++) {
				getline(file1, str, '|');
				file2 << str << "|";
			}

			while (file1) {
				getline(file1, str);
				file2 << str;
				if (file1)
					file2 << endl;
			}
			file1.close();
			file2.close();
			cout << s4 << "Employee has been updated!" << nl << nl;
			char fn1[] = "emp.txt", fn2[] = "temp.txt";
			recover(fn1, fn2);


		}
		else
			cout << s2 << sp4 << "Employee not found!" << nl << nl;

	}
	void recover(char* fn1, char* fn2)
	{
		remove(fn1);
		rename(fn2, fn1);
	}

	void displayUsers()
	{
		string str;
		fstream file;
		file.open("emp.txt", ios::binary | ios::in);
		if (!file) {
			system("cls");
			cout << s4 << "Error Occured" << nl;
			return;
		}
		cout << nl << "\tEmployee ID" << s2 << "Name" << s2 << "Age" << s2 << "Salary" << s1 << sp2 << "Experience" << nl << nl;
		while (file) {
			getline(file, str, '|');
			cout << str;
		}
		file.close();
		int t = 80;
		cout << nl;
		while (t--)
			cout << "-";
		cout << nl << nl;
		file.close();
	}

	void modLeave()
	{
		string id, str;
		int found = 0, count = 0;
		fstream file1, file2;
		file1.open("leave.txt", ios::binary | ios::in);
		cout << nl << s2 << "--- A P P L Y  L E A V E ---" << nl << nl;
		cout << s2 << sp4 << "Enter the Employee ID : ";
		cin >> id;
		cout << nl;
		id.resize(8);
		if (!file1) {
			system("cls");
			cout << s4 << "Error Occured" << nl;
			return;
		}
		int index = 0;
		while (file1) {
			file1.seekg(index, ios::beg);
			getline(file1, str, '|');
			if (str == id) {
				found = 1;
				break;
			}
			else {
				index += 100;
				str.clear();
				count--;
			}
		}
		file1.close();
		if (found == 1)
		{
		start:
			string sdate, edate;
			int ch, com = 7, beg, end, nol, ex = 0, lea, tot, days = 0, leave, nod;
			float sal, per;
			cout << s2 << sp4 << "1. CASUAL LEAVE" << nl;
			cout << s2 << sp4 << "2. SICK LEAVE" << nl;
			cout << s2 << sp4 << "3. STUDY LEAVE" << nl;
			cout << s2 << sp4 << "4. PARENTAL LEAVE" << nl << nl;
			cout << s0 << cyp;
			cin >> ch;
			cout << "=========================================================";
			cout << nl;
			if (ch == 1) { beg = 0, end = 3, tot = 20, per = .08; }
			else if (ch == 2) { beg = 1, end = 2, tot = 15, per = 0.05; }
			else if (ch == 3) { beg = 2, end = 1, tot = 10, per = 0.03; }
			else if (ch == 4) { beg = 3, end = 0, tot = 40, per = 0.15; }
			file1.open("leave.txt", ios::binary | ios::in);
			file2.open("temp1.txt", ios::binary | ios::app);
			while (count--) {
				getline(file1, str);
				file2 << str << endl;
			}
			for (int i = 0; i < 2; i++) {
				getline(file1, str, '|');
				file2 << str << "|";
			}
			for (int i = 0; i < beg; i++) {
				getline(file1, str, '|');
				file2 << str << "|";
			}
			cout << s2 << sp4 << "Enter the number of leaves : ";
			cin >> nol;
			getline(file1, str, '|');
			stringstream buf1(str);
			buf1 >> lea;
			leave = lea;
			if (lea - nol < 0)
				days = abs(lea - nol);
			lea = lea - nol;
			if (days != 0)
				lea = 0;
			fstream buf2;
			buf2.open("mod.txt", ios::binary | ios::out);
			buf2 << lea << "/" << tot << "-" << days;
			buf2.close();
			buf2.open("mod.txt", ios::binary | ios::in);
			getline(buf2, str);
			buf2.close();
			remove("mod.txt");
			str.resize(10);
			file2 << str << "|";
			for (int i = 0; i < end; i++) {
				getline(file1, str, '|');
				file2 << str << "|";
			}
			getline(file1, str, '|');
			sal = getSal(id);

			if (leave - nol < 0)
				sal = sal - (float)sal * per * abs(tot - leave);

			ostringstream buf4;
			buf4 << sal;
			str = buf4.str();;
			str.resize(8);
			file2 << str << "|";

			cout << s2 << sp4 << "Enter the Start Date(dd/mm/yyyy) : ";
			cin >> sdate;
			cout << s2 << sp4 << "Enter the End Date(dd/mm/yyy) : ";
			cin >> edate;
			sdate.resize(10);
			edate.resize(10);
			file2 << sdate << "|";
			file2 << edate << "|";
			for (int i = 0; i < 3; i++)
				getline(file1, str, '|');

			stringstream buf5(str);
			buf5 >> nod;
			nod = nod + nol;

			ostringstream buf6;
			buf6 << nod;
			str = buf6.str();
			str.resize(5);
			file2 << str << "|";

			while (file1) {
				getline(file1, str);
				file2 << str;
				if (file1)
					file2 << endl;
			}
			file1.close();
			file2.close();
			char fn1[] = "leave.txt", fn2[] = "temp1.txt";
			recover(fn1, fn2);
			cout << s4 << "Leave updated!" << nl << nl;
		}
		else
			cout << s4 << "User not found!" << nl << nl;
	}

	void dispLeave()
	{
		string str;
		fstream file;
		file.open("leave.txt", ios::binary | ios::in);
		if (!file) {
			system("cls");
			cout << s4 << "Error Occured" << nl;
			return;
		}
		cout << nl << "Employee ID\t" << "Name\t\t" << "CL(20)\t\t" << "SL(15)\t\t" << "STL(10)\t\t" << "PL(40)\t\t" << "Salary\t\t" << "Start Date" << sp2 << sp2 << "End Date" << sp2 << sp2 << "NoofLeaves" << nl << nl;
		while (file) {
			getline(file, str, '|');
			cout << str << "\t";
		}
		cout << nl << nl;
		cout << "Note : This table shows remaining leaves." << nl << sp2 << "CL : CASUAL LEAVE" << nl << sp2 << "SL : SICK LEAVESEAVE" << nl << sp2 << "STL : STUDY LEAVE" << nl << sp2 << "PL : PARENTAL LEAVE" << nl << sp2 << "Number after '-' sign indicates extra leaves." << nl << nl;
		file.close();
	}

	void deleteLeave()
	{
		string id, str;
		int found = 0, count = 0;
		fstream file1, file2;
		file1.open("leave.txt", ios::binary | ios::in);
		cout << s2 << "--- D E L E T E  L E A V E ---" << nl << nl;
		cout << s2 << sp4 << "Enter the Employee ID to delete : ";
		cin >> id;
		id.resize(8);
		if (!file1) {
			system("cls");
			cout << s2 << sp4 << "Error Occured" << nl;
			return;
		}
		int index = 0;
		while (file1) {
			file1.seekg(index, ios::beg);
			getline(file1, str, '|');
			if (str == id) {
				found = 1;
				break;
			}
			else {
				index += 100;
				str.clear();
				count = count + 1;
			}
		}
		file1.close();
		if (found == 1)
		{
			file1.open("leave.txt", ios::binary | ios::in);
			file2.open("temp1.txt", ios::binary | ios::app);
			while (count > 0) {
				getline(file1, str);
				file2 << str;
				count = count - 1;
				if (count > 0)
					file2 << nl;
			}
			for (int i = 0; i < 2; i++) {
				getline(file1, str, '|');
				file2 << str << "|";
			}
			str = "20/20-0"; str.resize(10);
			file2 << str << "|";
			str = "15/15-0"; str.resize(10);
			file2 << str << "|";
			str = "10/10-0"; str.resize(10);
			file2 << str << "|";
			str = "40/40-0"; str.resize(10);
			file2 << str << "|";
			float sal = getSal(id);
			ostringstream buf;
			buf << sal;
			str = buf.str();
			str.resize(8);
			file2 << str << "|";
			str = "-"; str.resize(10);
			file2 << str << "|" << str << "|";
			str = "0"; str.resize(10);
			file2 << str << "|";
			for (int i = 0; i < 8; i++)
				getline(file1, str, '|');
			while (file1) {
				getline(file1, str);
				file2 << str;
				if (file1)
					file2 << endl;
			}
			file1.close();
			file2.close();
			char fn1[] = "leave.txt", fn2[] = "temp1.txt";
			recover(fn1, fn2);
		}
		else
			cout << s2 << sp4 << "User not found!" << nl;
	}

	float getSal(string id)
	{
		fstream file;
		float sal;
		string str;
		file.open("salary.txt", ios::binary | ios::in);
		if (!file) {
			system("cls");
			cout << s4 << "Error Occured" << nl;
			return 0;
		}
		while (file) {
			getline(file, str, '|');
			str.resize(8);
			if (str == id)
				break;
		}
		str.clear();
		getline(file, str, '|');
		stringstream buf(str);
		buf >> sal;
		file.close();
		return sal;
	}
	void searchLeave()
	{
		string id, str;
		cout << nl << s2 << "--- S E A R C H  L E A V E ---" << nl << nl;
		cout << s2 << sp4 << "Enter the Employee ID : ";
		cin >> id;
		id.resize(8);
		fstream file;
		file.open("leave.txt", ios::binary | ios::in);
		if (!file) {
			system("cls");
			cout << s4 << "Error Occured" << nl;
			return;
		}
		while (file) {
			getline(file, str, '|');
			str.resize(8);
			if (str == id) {
				break;
			}
		}
		cout << nl << "Employee ID\t" << "Name\t\t" << "CL(20)\t\t" << "SL(15)\t\t" << "STL(10)\t\t" << "PL(40)\t\t" << "Salary\t\t" << "Start Date" << sp2 << sp2 << "End Date" << sp2 << sp2 << "NoofLeaves" << nl << nl;
		cout << str << "\t";
		for (int i = 0; i < 9; i++) {
			getline(file, str, '|');
			cout << str << "\t";
		}
		file.close();
		cout << nl << nl;
	}









};
//class implementing functionalties of staff----------------------------------
class a {
	staff** f1;
	staff** f2;
	static int objectCount;
public:
	int size1 = 0, size2 = 0; //caclculating size of the file by line
	a() {
		if (objectCount == 0) { ///singleton design pattern

			ifstream fin;
			fin.open("staff.txt");
			string n;
			while (!fin.eof()) {
				getline(fin, n);
				size1++;
			}
			size1--;
			fin.close();
			fin.open("s2.txt");
			while (!fin.eof()) {
				getline(fin, n);
				size2++;
			}
			size2--;
			fin.close();

			//cout<<size2<<" "<<size1<<endl;
			f1 = new staff * [size1];
			f2 = new staff * [size2];
			populate_data();

		}
	}
	void populate_data() {
		ifstream fin;
		fin.open("staff.txt");
		string n, loc, job;
		bool b;
		int age, i = 0;
		while (!fin.eof()) {
			fin >> n >> age >> b >> loc >> job;
			f1[i] = new staff(n, age, b, loc, job);
			i++;
		}
		fin.close();
		i = 0;

		fin.open("s2.txt");
		while (!fin.eof()) {
			fin >> n >> age >> b >> loc >> job;
			f2[i] = new staff(n, age, b, loc, job);
			i++;
		}
		fin.close();

	}
	void show() {
		for (int i = 0; i < size1; i++) {
			f1[i]->show();
		}
		cout << endl;
		for (int i = 0; i < size2; i++) {
			f2[i]->show();
		}

	}

	bool search(string nam, int& m) {
		for (int i = 0; i < size1; i++) {
			if (f1[i]->name == nam) {
				f1[i]->a = true;
				return true;
			}
			m++;
		}
		for (int i = 0; i < size2; i++) {
			if (f2[i]->name == nam) {
				f2[i]->a = true;
				return true;
			}
			m++;
		}
		return false;
	}
	void out1() {
		ofstream fin;
		fin.open("staff.txt");
		for (int i = 0; i < size1; i++) {
			fin << f1[i]->name << " " << f1[i]->age << " " << f1[i]->a << " " << f1[i]->location << " " << f1[i]->job << endl;
		}
		fin.close();
	}
	void out2() {
		ofstream fin;
		fin.open("s2.txt");
		for (int i = 0; i < size2; i++) {
			fin << f2[i]->name << " " << f2[i]->age << " " << f2[i]->a << " " << f2[i]->location << " " << f2[i]->job << endl;
		}
		fin.close();
	}
	void menu() {
		string nam;
		cout << "Scan Fingerprint to Mark Attendance \n";
		cin >> nam;
		int m = 0, k, n;
		bool presence = search(nam, m);
		if (presence) {
			if (m >= size1) {
				k = m - size1;
				cout << "Welcome " << f2[k]->name << endl;
				cout << "1. check in \n" << "2. check out \n";
				cin >> n;
				switch (n) {
				case 1:
					f2[k]->a = true;
					f2[k]->show();
					out2();
					break;
				case 2:
					f2[k]->a = false;
					f2[k]->show();
					out2();
					break;
				default:
					cout << " ERRor. Program crashed \n";
				}


			}
			else {
				cout << "Welcome " << f1[m]->name << endl;
				cout << "1------> check in \n" << "2------> check out \n";
				cin >> n;
				switch (n) {
				case 1:
					f1[m]->a = true;
					f1[m]->show();
					out1();
					break;
				case 2:
					f1[m]->a = false;
					f1[m]->show();
					out1();
					break;
				default:
					cout << " ERRor. Program crashed \n";
				}

			}
		}
		else {
			cout << "Staff member not available ";
		}

	}

};

int a::objectCount = 0;

class floor_manager {
	string name;
	int num;
	int age;
	string location;
	floor_manager** e;
	staff** f1;
	staff** f2;

public:
	floor_manager() {
		e = new floor_manager * [2];
		ifstream fin;
		fin.open("floor_manager.txt");
		int i = 0;

		while (!fin.eof()) {
			fin >> name >> num >> location >> age;
			e[i] = new floor_manager(name, num, location, age);
			i++;
		}

	}
	floor_manager(string na, int n, string l, int a) {
		name = na;
		num = n;
		location = l;
		age = a;
	}
	int size1 = 0, size2 = 0;
	void a() {
		ifstream fin;
		fin.open("staff.txt");
		string n;
		while (!fin.eof()) {
			getline(fin, n);
			size1++;
		}
		size1--;
		fin.close();
		fin.open("s2.txt");
		while (!fin.eof()) {
			getline(fin, n);
			size2++;
		}
		size2--;
		fin.close();

		//cout<<size2<<" "<<size1<<endl;
		f1 = new staff * [size1];
		f2 = new staff * [size2];
		populate_data();
	}
	void populate_data() {
		ifstream fin;
		fin.open("staff.txt");
		string n, loc, job;
		bool b;
		int age, i = 0;
		while (!fin.eof()) {
			fin >> n >> age >> b >> loc >> job;
			f1[i] = new staff(n, age, b, loc, job);
			i++;
		}
		fin.close();
		i = 0;

		fin.open("s2.txt");
		while (!fin.eof()) {
			fin >> n >> age >> b >> loc >> job;
			f2[i] = new staff(n, age, b, loc, job);
			i++;
		}
		fin.close();

	}
	//===================================saving output in file 1================================
	void out1() {
		ofstream fin;
		fin.open("staff.txt");
		for (int i = 0; i < size1; i++) {
			fin << f1[i]->name << " " << f1[i]->age << " " << f1[i]->a << " " << f1[i]->location << " " << f1[i]->job << endl;
		}
		fin.close();
	}
	///=================================saving output in file2-----------------------------
	void out2() {
		ofstream fin;
		fin.open("s2.txt");
		for (int i = 0; i < size2; i++) {
			fin << f2[i]->name << " " << f2[i]->age << " " << f2[i]->a << " " << f2[i]->location << " " << f2[i]->job << endl;
		}
		fin.close();
	}
	void show_staff(staff** a, int s) {
		for (int i = 0; i < s; i++) {
			a[i]->show();
		}
	}
	//=============================searching satff memebr in object array================================
	bool search(staff** a, string nam, int& m, int s) {
		for (int i = 0; i < s; i++) {
			if (a[i]->name == nam) {
				return true;
			}
			m++;
		}
		return false;
	}

	///============================assigning duties to staff-------------------------------
	void Manage_staff(staff** a, int s) {
		string name;
		cout << "enter Staff Name \n";
		cin >> name;
		int i = 0, n;
		bool presence = search(a, name, i, s);
		if (presence) {
			cout << "Assign Duties: \n";
			cout << " 1------> Technicians \n 2------> Denters \n 3------> Electrician \n 4------> Mechanic \n";
			cin >> n;
			switch (n) {
			case 1:
				a[i]->job = "Technicians";
				a[i]->show();
				break;
			case 2:
				a[i]->job = "Denters";
				a[i]->show();
				break;
			case 3:
				a[i]->job = "Electrician";
				a[i]->show();
				break;
			case 4:
				a[i]->job = "Mechanic";
				a[i]->show();
				break;
			}
		}
		else {
			cout << "Staff member not available \n";
		}
	}
	//==================================================================================


	//======================performance of present week=============================
	void performance_week(staff** f, int** a, int size) {
		int* count = new int[size];
		for (int i = 0; i < size; i++) {
			count[i] = 0;
		}
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < 14; j++) {
				if (a[i][j] == 1) {
					count[i]++;
				}
			}
		}
		for (int i = 0; i < size; i++) {
			if (count[i] <= 7) {
				cout << f[i]->name << "\n Age: " << f[i]->age << " \n Presece: " << count[i] << " \n Job: " << f[i]->job << " \n Performance: Poor \n" << endl;
			}
			else if (count[i] > 7 && count[i] < 10) {
				cout << f[i]->name << "\n Age: " << f[i]->age << " \n Presece: " << count[i] << " \n Job: " << f[i]->job << " \n Performance: Good \n" << endl;
			}
			else
				cout << f[i]->name << "\n Age: " << f[i]->age << " \n Presece: " << count[i] << " \n Job: " << f[i]->job << " \n Performance: Excellent \n" << endl;

		}

	}
	////=========================performance of the last week==========================
	void performance_week_present(staff** f, int** a, int size) {
		int* count = new int[size];
		for (int i = 0; i < size; i++) {
			count[i] = 0;
		}
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < 7; j++) {
				if (a[i][j] == 1) {
					count[i]++;
				}
			}
		}
		for (int i = 0; i < size; i++) {
			if (count[i] <= 2) {
				cout << f[i]->name << "\n Age: " << f[i]->age << " \n Presece: " << count[i] << " \n Job: " << f[i]->job << " \n Performance: Poor \n" << endl;
			}
			else if (count[i] > 2 && count[i] < 4) {
				cout << f[i]->name << "\n Age: " << f[i]->age << " \n Presece: " << count[i] << " \n Job: " << f[i]->job << " \n Performance: Good \n" << endl;
			}
			else
				cout << f[i]->name << "\n Age: " << f[i]->age << " \n Presece: " << count[i] << " \n Job: " << f[i]->job << " \n Performance: Excellent \n" << endl;

		}

	}
	//---------------------------------------------------------------------

	//--------------performance of the day----------------------------------
	void performance_day(staff** f, int** a, int size) {
		int* count = new int[size];
		for (int i = 0; i < size; i++) {
			count[i] = 0;
		}
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < 14; j++) {
				if (a[i][j] == 1) {
					count[i]++;
				}
			}
		}
		for (int i = 0; i < size; i++) {
			if (count[i] <= 7) {
				cout << f[i]->name << "\n Age: " << f[i]->age << " \n Job: " << f[i]->job << " \n Performance: Poor \n" << endl;
			}
			else if (count[i] > 7 && count[i] < 10) {
				cout << f[i]->name << "\n Age: " << f[i]->age << " \n Job: " << f[i]->job << " \n Performance: Good \n" << endl;
			}
			else
				cout << f[i]->name << "\n Age: " << f[i]->age << " \n Job: " << f[i]->job << " \n Performance: Excellent \n" << endl;

		}


	}
	//-------------performance for 1 st floor manager-----------------------------------
	void performance_1() {
		system("CLS");
		ifstream fin;
		fin.open("p1.txt");
		string n, jo;
		int ag, m;
		int** array = new int* [size1];
		for (int i = 0; i < size1; i++) {
			array[i] = new int[14];
		}

		for (int i = 0; i < size1; i++) {
			fin >> n >> ag >> jo;
			for (int j = 0; j < 14; j++) {
				fin >> array[i][j];
			}
		}
		cout << "1. Performance of the Day \n" << "2. Performance of this Week \n" << "3. Performance of Last Week \n" << "4. Exit \n";
		cin >> m;
		switch (m) {
		case 1:

			performance_day(f1, array, size1);
			break;
		case 2:

			performance_week_present(f1, array, size1);
			break;
		case 3:

			performance_week(f1, array, size1);
			break;



		}
	}
	//-------------------------------------------------------------------------------------

	//==============================floor manager 2============
	void performance_2() {
		system("CLS");
		ifstream fin;
		fin.open("p2.txt");
		string n, jo;
		int ag, m;
		int** array = new int* [size1];
		for (int i = 0; i < size2; i++) {
			array[i] = new int[14];
		}

		for (int i = 0; i < size2; i++) {
			fin >> n >> ag >> jo;
			for (int j = 0; j < 14; j++) {
				fin >> array[i][j];
			}
		}
		cout << "1. Performance of the Day \n" << "2. Performance of this Week \n" << "3. Performance of Last Week \n" << "4. Exit \n";
		cin >> m;
		switch (m) {
		case 1:
			performance_day(f2, array, size2);
			break;
		case 2:
			performance_week_present(f2, array, size2);
			break;
		case 3:
			performance_week(f2, array, size2);
			break;



		}
	}
	void available_staff(staff** f, int size) {
		for (int i = 0; i < size; i++) {
			if (f[i]->a) {
				f[i]->show();
			}
		}
	}
	/// ----------------------menu or dashboard=-----------------------------------------
	void menu() {
		int n, m;
		a();
		cout << "Select Floor Manager: \n";
		cout << "1------> Qasim \n" << "2------> Khizer \n";
		cin >> n;
		switch (n) {
		case 1:
			system("CLS");

			m = 0;
			while (m < 5) {
				cout << "1. Show Staff Details \n" << "2. Manage Staff \n" << "3. Performance Report \n" << "4. Show available staff  \n" << "5. Process Return Items \n" << "6. Exit \n";
				cin >> m;
				switch (m) {
				case 1:
					system("CLS");
					show_staff(f1, size1);
					break;
				case 2:
					system("CLS");
					Manage_staff(f1, size1);
					out1();
					break;
				case 3:
					performance_1();
					break;
				case 4:
					available_staff(f1, size1);
					//process return item======================================	

				}
			}
			break;
		case 2:
			m = 0;
			while (m < 4) {

				cout << "1. Show Staff Details \n" << "2. Manage Staff \n" << "3. Performance Report \n" << "4. Show available staff  \n" << "5. Process Return Items \n" << "6. Exit \n";
				cin >> m;
				switch (m) {
				case 1:
					system("CLS");
					show_staff(f2, size2);
					break;
				case 2:
					system("CLS");
					Manage_staff(f2, size2);
					out2();
					break;
				case 3:
					system("CLS");
					performance_2();
					break;
				case 4:
					available_staff(f2, size2);
					break;
					//case 4:
					/////process return item======================================	
				}
			}
		case 3:

			break;
		}

	}
	////--------------------------------------------------------	
	void show_floorManager() {
		for (int i = 0; i < 2; i++) {
			cout << e[i]->name << " " << e[i]->age << " " << endl;
		}
	}


};

class managerdashboard {
protected:
	workshopmanager c;
	floor_manager f1;
	a a1;
public:
	void fmdashboard() {
		f1.menu();


	}
	void manageattenance() {
		a1.menu();
	}
	void wmdashboard() {


		while (true) {
		start:
			int ch;
			cout << "=========================================================" << nl;
			cout << s0 << "------ L E A V E  M A N A G E M E N T  S Y S T E M ------" << nl;
			cout << "=========================================================    " << nl << nl;
			cout << s2 << "--- M A I N  M E N U ---" << nl << nl;
			cout << s2 << sp4 << "1. APPLY LEAVE" << nl;
			cout << s2 << sp4 << "2. DELETE LEAVE" << nl;
			cout << s2 << sp4 << "3. SEARCH LEAVE" << nl;
			cout << s2 << sp4 << "4. MODIFY LEAVE" << nl;
			cout << s2 << sp4 << "5. DISPLAY ALL LEAVES" << nl;
			cout << s2 << sp4 << "6. USER MANAGEMENT" << nl;
			cout << s2 << sp4 << "7. EXIT" << nl;
			cout << nl << s0 << cyp;
			cin >> ch;
			cout << "=========================================================";
			cout << nl;
			switch (ch)
			{
			case 1:
				c.modLeave();
				break;
			case 2:
				c.deleteLeave();
				break;
			case 3:
				c.searchLeave();
				break;
			case 4:
				c.modLeave();
				break;
			case 5:
				c.dispLeave();
				break;
			case 6:
				int ch1;
				cout << nl << s2 << "--- U S E R  M E N U ---" << nl << nl;
				cout << s2 << sp4 << "1. ADD employee" << nl << s2 << sp4 << "2. MODIFY user" << nl;
				cout << s2 << sp4 << "3. SHOW ALL employee" << nl;
				cout << nl << s0 << cyp;
				cin >> ch1;
				cout << "=========================================================";
				cout << nl;
				if (ch1 == 1)
					c.addUser();
				else if (ch1 == 2)
					c.modUser();
				else if (ch1 == 3)
					c.displayUsers();
				break;

			case 7:
				exit(0);

			default: goto start;
			}
		}


	}





};

class myinterface {
private:
	GUI i;
	sgp s;
public:
	void interfacestart() {
		int choice1;

		cout << "Welcome To S&J motors" << endl;
		cout << "Press 1 you are a user" << endl;
		cout << "Press 2 if you are a manager" << endl;
		cout << "Press 3 to exit" << endl;
		cin >> choice1;
		if (choice1 == 1) {
			i.welcomescreen();
			s.signup();
		}
		if (choice1 == 2) {

		}

		else {

		}









	}




};

class managerlog {

public:

	bool managerlogin(string& z1) {
		string u;
		string p;
		cout << "You have reached Manager login page \n Enter name and Password to continue: " << endl;
		cin >> u;
		cin >> p;

		int count = 0;
		ifstream file("managerlogin.txt");
		string x, y, z;
		if (file.is_open() == false) { cout << "cant open file"; }
		while (!file.eof())
		{
			file >> x >> y >> z;
			if (x == u && y == p) {
				count++;
				break;
			}
		}
		if (count > 0) {
			z1 = z;
			return true;
		}
		else { return 0; }


	}

};

int main()
{
	int opt = -5;
	GUI obj;
	sgp objx;
	lgn objy;
	while (opt < 0 || opt>3)
	{
		cout << "\nPlease choose 0-exit 1-sign up 2-login\n\t3-Manager login\n";
		cin >> opt;
		if (opt < 0 || opt>3)
		{
			cout << "\n*choose a correct option*\n";
		}
	}
	if (opt == 0) {}
	if (opt == 1)
	{
		objx.welcomescreen();
		objx.signup();
		obj = objx;
	}
	if (opt == 2)
	{
		objy.welcomescreen();
		bool x = objy.login();
		while (x == false)
		{
			x = objy.login();
		}
		obj = objy;
	}
	if (opt == 3)//manager login
	{


		string x;

		managerdashboard m1;
		managerlog ml1;
		if (ml1.managerlogin(x) == true) {
			cout << "true";
			cout << "X" << endl;
			if (x == "wm") {
				cout << "Workshop manager" << endl;;
				m1.wmdashboard();
			}
			else {
				m1.fmdashboard();

				m1.manageattenance();
			}
		}

	}
	int optt = -5;
	while (optt < 0 || optt>4)
	{
		cout << "Please choose 0-Exit 1-Enter Average \n2-Book Appointment 3-View Todays Predicted Mileage\n4-show user details: ";
		cin >> optt;
		if (optt < 0 || optt>4)
		{
			cout << "\n*choose a correct option*\n";
		}
	}
	if (optt == 4)
	{
		obj.userdetails();
	}
	if (optt == 0)
	{

	}
	user X = obj.returnuser(); //loads user into a user variable
	if (optt == 1)
	{
		float avg;
		cout << "Enter Todays Mileage: ";
		cin >> avg;
		X.enteravg(avg);

		cout << "Projected Average for tommorow is: " << X.getmileage();
	}
	if (optt == 2)
	{
		float cost = 0;
		int opttt = 0;
		int exit = 9999;
		while (exit != 0)
		{
			opttt = 0;
			while (opttt < 1 || opttt>5)
			{
				cout << "Please choose the car part that needs repair 1-Engine($1000) 2-Door($50) 3-Windows($40) 4-Interior($15) 5-Tyres($100)\n";
				cin >> opttt;
				if (opttt < 1 || opttt>5)
				{
					cout << "\n*choose a correct option*\n";
				}
			}
			switch (opttt)
			{
			case 1:
				cost += 1000;
				break;
			case 2:
				cost += 50;
				break;
			case 3:
				cost += 40;
				break;
			case 4:
				cost += 15;
				break;
			case 5:
				cost += 100;
				break;
			}

			cout << "Enter 0 to Stop Adding Items, Any other number to continue";
			cin >> exit;
		}
		X.booking(cost);
	}
	if (optt == 3)
	{
		cout << "Projected Average for today is: " << X.getmileage();
	}



	cout << endl;
	system("pause");
	return 0;
}